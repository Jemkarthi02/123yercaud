import React from 'react';
import { 
  X, 
  Phone, 
  Clock, 
  ShieldCheck, 
  Sparkles, 
  Building2, 
  CheckCircle2, 
  ArrowRight,
  ExternalLink 
} from 'lucide-react';

interface ContactAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  phoneNumber?: string;
  timing?: string;
}

export const ContactAdminModal: React.FC<ContactAdminModalProps> = ({
  isOpen,
  onClose,
  phoneNumber = '+91 94439 16492',
  timing = '10.00 AM - 5.00 PM',
}) => {
  if (!isOpen) return null;

  const cleanNumber = phoneNumber.replace(/\D/g, '');
  const waNumber = cleanNumber.startsWith('91') ? cleanNumber : `91${cleanNumber}`;
  const whatsappUrl = `https://wa.me/${waNumber}?text=${encodeURIComponent(
    'Hello Admin, I would like to list my business/service/property on 123yercaud.com. Please share listing details.'
  )}`;

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-4 bg-slate-800/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 my-auto"
        id="contact-admin-modal-card"
      >
        {/* Header */}
        <div className="bg-slate-800 text-white px-6 py-4 flex items-center justify-between border-b border-slate-700">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                123yercaud.com Directory
              </span>
              <h3 className="text-base font-bold text-white leading-tight">
                List Your Business / Service
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-slate-700">
          {/* Main User Directive Announcement Banner */}
          <div className="bg-amber-50 border-2 border-amber-400/90 rounded-2xl p-5 sm:p-6 text-center shadow-xs">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500 text-slate-900 font-black text-xs uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              Listing Instructions
            </span>

            {/* Exact User Requested Pop-up Message */}
            <h4 className="text-lg sm:text-xl font-black text-slate-900 leading-snug">
              To List Your Business/Service Contact admin : <span className="text-red-600 font-mono tracking-tight block sm:inline mt-1 sm:mt-0 font-black">{phoneNumber}</span>
            </h4>

            <div className="mt-3.5 inline-flex items-center gap-1.5 text-xs font-bold text-slate-800 bg-white/95 px-3 py-1.5 rounded-lg border border-amber-300 shadow-2xs">
              <Clock className="w-3.5 h-3.5 text-red-600" />
              <span>Admin Timing : {timing}</span>
            </div>
          </div>

          {/* Quick info bullet points */}
          <div className="space-y-2.5 text-xs text-slate-600 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex items-start gap-2.5 font-medium text-slate-800">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong>Verified Directory Policy:</strong> Users cannot list properties directly to ensure 100% genuine tourist safety and authentic pricing.</span>
            </div>
            <div className="flex items-start gap-2.5 font-medium text-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>Our admin team will help upload your resort photos, room amenities, pricing, map directions, and contact details.</span>
            </div>
          </div>

          {/* Direct CTA Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {/* Direct Call to Admin */}
            <a
              href={`tel:${phoneNumber}`}
              className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Call Admin Direct</span>
            </a>

            {/* Direct WhatsApp to Admin */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
            >
              <svg className="w-4 h-4 fill-white shrink-0" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
              <span>WhatsApp Admin</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
